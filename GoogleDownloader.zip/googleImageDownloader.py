from cmath import e
from re import search
from PIL import Image
from selenium import webdriver
from bs4 import BeautifulSoup
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager
import urllib.request
import time
import os
import sys

searchterm=sys.argv[1]
site = 'https://www.google.com/search?tbm=isch&q='+searchterm
numberOfScrolls=2

driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))
driver.get(site)

i=0
while i<numberOfScrolls:
    driver.execute_script("window.scrollTo(0,document.body.scrollHeight)")
    try:
        driver.find_element("/html/body/div[2]/c-wiz/div[3]/div[1]/div/div/div/div/div[5]/input").click()
    except Exception as e:
        pass
    time.sleep(5)
    i+=1

soup = BeautifulSoup(driver.page_source, 'html.parser')

driver.close();
img_tags = soup.find_all("img", class_="rg_i")
destination=sys.argv[4]

count = 0
for i in img_tags:
    try:
        dataFormat=sys.argv[3]
        path=urllib.request.urlretrieve(i['src'],destination +"\\"+searchterm+ str(count)+dataFormat)

        image = Image.open(destination +"\\"+searchterm+ str(count)+dataFormat)
       
        if(image.width < image.height*6):
            image = image.resize((int(sys.argv[2]),int(sys.argv[2])),Image.ANTIALIAS)
            image.save(fp=destination+"\\"+searchterm+ str(count)+dataFormat)
            count += 1
        else:
            os.remove(destination+"\\"+searchterm+ str(count)+dataFormat)

    except Exception as e:
        pass